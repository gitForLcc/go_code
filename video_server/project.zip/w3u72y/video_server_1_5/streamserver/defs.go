package main 

const (
	VIDEO_DIR = "./videos/"
	MAX_UPLOAD_SIZE = 1024 * 1024 * 50 //50MB
)